# Raspberry Pi TTS System Simulator
# Simulates a Text-to-Speech system for Raspberry Pi deployment
print("Starting Raspberry Pi TTS System...")

import time
import gc

# Simulate system initialization
print("Initializing hardware...")
time.sleep(1)

class TTSEngine:
    """Raspberry Pi TTS Engine Simulator"""
    
    def __init__(self):
        self.voices = [
            {'id': 0, 'name': 'David (Male English)', 'lang': 'en'},
            {'id': 1, 'name': 'Emma (Female English)', 'lang': 'en'},
            {'id': 2, 'name': 'Carlos (Male Spanish)', 'lang': 'es'},
            {'id': 3, 'name': 'Sofia (Female Spanish)', 'lang': 'es'},
            {'id': 4, 'name': 'Pierre (Male French)', 'lang': 'fr'},
            {'id': 5, 'name': 'Marie (Female French)', 'lang': 'fr'}
        ]
        self.current_voice = 0
        self.rate = 150  # Words per minute
        self.volume = 1.0
        self.history = []
        
        print("✓ TTS Engine initialized")
        print(f"✓ {len(self.voices)} voices loaded")
        print("✓ Audio system ready")
    
    def speak(self, text):
        """Convert text to speech (simulated)"""
        if not text or len(text.strip()) == 0:
            print("❌ Error: No text provided")
            return False
        
        # Text preprocessing
        text = self._preprocess_text(text)
        
        # Simulate processing
        word_count = len(text.split())
        processing_time = max(1, word_count / 10)
        
        voice = self.voices[self.current_voice]
        
        print(f"\n🔊 TTS CONVERSION")
        print("=" * 40)
        print(f"Voice: {voice['name']}")
        print(f"Rate: {self.rate} WPM")
        print(f"Volume: {self.volume}")
        print(f"Words: {word_count}")
        print("-" * 40)
        print(f"Text: \"{text}\"")
        print("=" * 40)
        print("🎵 [AUDIO PLAYING ON RASPBERRY PI SPEAKERS]")
        print("=" * 40)
        
        # Simulate processing time
        time.sleep(min(processing_time, 3))
        
        # Add to history
        self.history.append({
            'text': text[:50] + ('...' if len(text) > 50 else ''),
            'voice': voice['name'],
            'timestamp': time.time()
        })
        
        if len(self.history) > 5:
            self.history = self.history[-5:]
        
        print("✓ Conversion completed!")
        return True
    
    def set_voice(self, voice_id):
        """Change voice"""
        try:
            voice_id = int(voice_id)
            if 0 <= voice_id < len(self.voices):
                self.current_voice = voice_id
                print(f"✓ Voice changed to: {self.voices[voice_id]['name']}")
                return True
            else:
                print(f"❌ Voice {voice_id} not found (0-{len(self.voices)-1})")
                return False
        except:
            print("❌ Invalid voice ID")
            return False
    
    def set_rate(self, rate):
        """Set speech rate"""
        try:
            rate = int(rate)
            if 50 <= rate <= 300:
                self.rate = rate
                print(f"✓ Speech rate set to: {rate} WPM")
                return True
            else:
                print("❌ Rate must be 50-300 WPM")
                return False
        except:
            print("❌ Invalid rate value")
            return False
    
    def set_volume(self, volume):
        """Set volume"""
        try:
            volume = float(volume)
            if 0.0 <= volume <= 1.0:
                self.volume = volume
                print(f"✓ Volume set to: {volume}")
                return True
            else:
                print("❌ Volume must be 0.0-1.0")
                return False
        except:
            print("❌ Invalid volume value")
            return False
    
    def list_voices(self):
        """List available voices"""
        print("\n🎤 AVAILABLE VOICES:")
        print("-" * 30)
        for voice in self.voices:
            current = " ◄ CURRENT" if voice['id'] == self.current_voice else ""
            print(f"{voice['id']}. {voice['name']}{current}")
        print("-" * 30)
    
    def show_history(self):
        """Show recent conversions"""
        if not self.history:
            print("📜 No history available")
            return
        
        print("\n📜 RECENT CONVERSIONS:")
        print("-" * 40)
        for i, entry in enumerate(self.history, 1):
            print(f"{i}. \"{entry['text']}\"")
            print(f"   Voice: {entry['voice']}")
        print("-" * 40)
    
    def _preprocess_text(self, text):
        """Improve text for speech"""
        # Handle special characters
        replacements = {
            '&': ' and ',
            '@': ' at ',
            '%': ' percent ',
            '#': ' number ',
            '+': ' plus ',
            '=': ' equals '
        }
        
        for char, replacement in replacements.items():
            text = text.replace(char, replacement)
        
        return text.strip()

def show_help():
    """Display help information"""
    print("\n📖 RASPBERRY PI TTS COMMANDS:")
    print("=" * 35)
    print("Basic Commands:")
    print("  help          - Show this help")
    print("  speak <text>  - Convert text to speech")
    print("  exit          - Exit program")
    print()
    print("Voice Commands:")
    print("  voices        - List available voices")
    print("  voice <id>    - Change voice (0-5)")
    print("  rate <wpm>    - Set speech rate (50-300)")
    print("  volume <vol>  - Set volume (0.0-1.0)")
    print()
    print("Utility Commands:")
    print("  history       - Show recent conversions")
    print("  demo          - Run demonstration")
    print("  info          - Show system info")
    print("=" * 35)

def show_info(tts):
    """Show system information"""
    print("\n🖥️  SYSTEM INFORMATION:")
    print("=" * 30)
    print("Hardware: Raspberry Pi 4B")
    print("OS: Raspberry Pi OS")
    print("TTS Engine: pyttsx3 + gTTS")
    print("Audio: 3.5mm + HDMI")
    print(f"Current Voice: {tts.voices[tts.current_voice]['name']}")
    print(f"Speech Rate: {tts.rate} WPM")
    print(f"Volume: {tts.volume}")
    print(f"Memory Free: {gc.mem_free()} bytes")
    print("=" * 30)

def run_demo(tts):
    """Run TTS demonstration"""
    print("\n🎭 RUNNING TTS DEMONSTRATION")
    print("=" * 35)
    
    demos = [
        "Welcome to Raspberry Pi Text to Speech!",
        "This system supports multiple voices and languages.",
        "You can control speech rate and volume.",
        "Perfect for IoT projects and accessibility!"
    ]
    
    for i, text in enumerate(demos, 1):
        print(f"\nDemo {i}/4:")
        if i == 2:
            tts.set_voice(1)  # Change to female voice
        elif i == 3:
            tts.set_rate(200)  # Faster speech
        
        tts.speak(text)
        time.sleep(0.5)
    
    print("\n🎭 Demo completed!")

def main():
    """Main program loop"""
    print("\n" + "=" * 50)
    print("🎤 RASPBERRY PI TTS SYSTEM")
    print("=" * 50)
    print("Interactive Text-to-Speech System")
    print("Type 'help' for commands or 'exit' to quit")
    print("=" * 50)
    
    # Initialize TTS engine
    tts = TTSEngine()
    
    while True:
        try:
            # Get user input
            user_input = input("\nTTS> ").strip().lower()
            
            if not user_input:
                continue
            
            # Parse command
            parts = user_input.split(' ', 1)
            command = parts[0]
            
            # Handle commands
            if command == 'exit':
                print("👋 Goodbye!")
                break
            
            elif command == 'help':
                show_help()
            
            elif command == 'speak':
                if len(parts) > 1:
                    tts.speak(parts[1])
                else:
                    print("Usage: speak <text>")
            
            elif command == 'voices':
                tts.list_voices()
            
            elif command == 'voice':
                if len(parts) > 1:
                    tts.set_voice(parts[1])
                else:
                    print("Usage: voice <0-5>")
            
            elif command == 'rate':
                if len(parts) > 1:
                    tts.set_rate(parts[1])
                else:
                    print("Usage: rate <50-300>")
            
            elif command == 'volume':
                if len(parts) > 1:
                    tts.set_volume(parts[1])
                else:
                    print("Usage: volume <0.0-1.0>")
            
            elif command == 'history':
                tts.show_history()
            
            elif command == 'demo':
                run_demo(tts)
            
            elif command == 'info':
                show_info(tts)
            
            else:
                # Treat as direct speech input
                tts.speak(user_input)
        
        except KeyboardInterrupt:
            print("\n👋 Program interrupted. Goodbye!")
            break
        except Exception as e:
            print(f"❌ Error: {e}")

# Start the program
if __name__ == "__main__":
    main()
# Raspberry Pi Text-to-Speech System

A comprehensive TTS system simulator designed for Raspberry Pi deployment.

## Features
- Multiple voice selection (6 voices in 3 languages)
- Adjustable speech rate (50-300 WPM)  
- Volume control (0.0-1.0)
- Text preprocessing for better speech quality
- Conversion history tracking
- Interactive command interface

## How to Use
1. Click ▶️ to start the simulation
2. Type commands in the terminal:
   - `help` - Show all commands
   - `speak Hello World` - Convert text to speech
   - `voices` - List available voices
   - `voice 1` - Change to voice 1
   - `rate 200` - Set speech rate to 200 WPM
   - `demo` - Run demonstration

## Commands Reference
- **speak <text>** - Convert text to speech
- **voice <0-5>** - Select voice by ID
- **rate <50-300>** - Set words per minute
- **volume <0.0-1.0>** - Set volume level
- **voices** - List all voices
- **history** - Show recent conversions
- **demo** - Run feature demonstration
- **info** - Display system information
- **exit** - Quit program

## Real Hardware Implementation
This simulation represents a TTS system that would run on:
- Raspberry Pi 4 Model B
- Connected speakers via 3.5mm or HDMI
- pyttsx3 (offline) + gTTS (online) engines
- Flask web interface for browser access

## Bonus Features Implemented
✅ Multiple voices and languages  
✅ Speech rate control  
✅ Volume adjustment  
✅ Error handling  
✅ Text preprocessing  
✅ Interactive CLI